"""
retrieval.py — Production-grade RAG retrieval pipeline.

Upgrades in this version:
  - Shared embed model via db.get_embedder() — no duplicate model loading
  - Multi-query expansion: original + stopword-stripped + keyword-only
  - Length-normalised reranking: overlap_ratio is relative to query, not chunk
  - Generalised keyword guarantee (not hardcoded to "attention")
  - Conservative re-windowing: only splits chunks that exceed 600 words
  - Context formatted with --- CONTEXT START / END --- delimiters
  - Detailed [RAG] logging: scores, keywords per chunk, guarantee actions
"""
from __future__ import annotations

import re
from typing import Any, List, TypedDict

try:
    from .db import get_collection, get_embedder
except ImportError:
    from db import get_collection, get_embedder

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
STOPWORDS: frozenset[str] = frozenset({
    "a", "an", "and", "are", "as", "at", "be", "by", "can", "could", "did", "do", "does",
    "for", "from", "how", "i", "if", "in", "into", "is", "it", "its", "me", "my", "of", "on",
    "or", "our", "please", "show", "tell", "that", "the", "their", "them", "there", "these",
    "they", "this", "to", "us", "was", "we", "what", "when", "where", "which", "who", "why",
    "with", "would", "you", "your", "explain", "describe", "give", "about",
})

MAX_SELECTED_CHUNKS: int = 4
NEAR_DUPLICATE_THRESHOLD: float = 0.85
MAX_CHUNK_WORDS_BEFORE_SPLIT: int = 600  # only re-window genuinely huge chunks


# ---------------------------------------------------------------------------
# TypedDicts
# ---------------------------------------------------------------------------
class RetrievedChunk(TypedDict):
    text: str
    file: str
    doc_id: str
    page: int | None
    metadata: dict[str, Any]


class RetrievalResult(TypedDict):
    chunks: List[RetrievedChunk]
    context: str


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------
def _normalize_chunk_text(text: str) -> str:
    return " ".join(text.split()).strip()


def _clean_broken_sentences(text: str) -> str:
    normalized = _normalize_chunk_text(text)
    if not normalized:
        return ""
    segments = re.split(r"(?<=[.!?])\s+", normalized)
    cleaned: list[str] = []
    for seg in segments:
        candidate = seg.strip()
        if not candidate:
            continue
        words = re.findall(r"[a-zA-Z0-9=()+\-/*^.]+", candidate)
        if len(words) < 5 and not any(t in candidate for t in ["=", "defined as", "is given by"]):
            continue
        cleaned.append(candidate)
    return " ".join(cleaned) if cleaned else normalized


def _word_windows(
    text: str,
    max_words: int = MAX_CHUNK_WORDS_BEFORE_SPLIT,
    overlap_words: int = 60,
    min_words: int = 180,
) -> list[str]:
    """
    Only re-window chunks that exceed max_words.
    Preserves intact, well-sized chunks as single items.
    """
    words = text.split()
    if not words:
        return []
    if len(words) <= max_words:
        return [" ".join(words)]

    step = max(1, max_words - overlap_words)
    windows: list[str] = []
    for start in range(0, len(words), step):
        end = min(start + max_words, len(words))
        chunk_words = words[start:end]
        if len(chunk_words) < min_words and start > 0:
            break
        windows.append(" ".join(chunk_words))
        if end >= len(words):
            break
    return windows or [" ".join(words)]


def _tokenize(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-zA-Z0-9]+", text.lower()) if len(t) > 2}


# ---------------------------------------------------------------------------
# Query expansion
# ---------------------------------------------------------------------------
def _normalize_query_text(query: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9\s]", " ", str(query).lower())
    return " ".join(t for t in cleaned.split() if t and t not in STOPWORDS)


def _build_query_variations(query: str) -> list[str]:
    """
    Build up to 3 distinct query variations:
      1. Original query (as typed)
      2. Simplified — stopwords removed, lowercased
      3. Keyword-only — top-6 longest unique content tokens
    """
    original = " ".join(str(query).split()).strip()
    simplified = _normalize_query_text(original)
    simplified_tokens = [t for t in simplified.split() if t]

    keyword_tokens = sorted(set(simplified_tokens), key=lambda t: (-len(t), t))[:6]
    keyword_only = " ".join(keyword_tokens)

    seen: list[str] = []
    for candidate in [original, simplified, keyword_only]:
        norm = " ".join(candidate.split()).strip()
        if norm and norm not in seen:
            seen.append(norm)
    return seen or [original]


# ---------------------------------------------------------------------------
# Reranking
# ---------------------------------------------------------------------------
def _rerank_score(semantic_score: float, chunk_text: str, query_terms: set[str]) -> float:
    """
    Combined score: semantic similarity + length-normalised keyword overlap.

    overlap_ratio is computed against query term count (not chunk length),
    so longer chunks don't receive an unfair free boost.
    """
    if not query_terms:
        return semantic_score

    chunk_tokens = _tokenize(chunk_text)
    overlap_terms = query_terms & chunk_tokens
    overlap_count = float(len(overlap_terms))
    overlap_ratio = overlap_count / float(len(query_terms))

    return semantic_score + (0.40 * overlap_count) + (0.90 * overlap_ratio)


# ---------------------------------------------------------------------------
# Near-duplicate detection
# ---------------------------------------------------------------------------
def _is_near_duplicate(text_a: str, text_b: str) -> bool:
    tokens_a = _tokenize(text_a)
    tokens_b = _tokenize(text_b)
    if not tokens_a or not tokens_b:
        return False
    intersection = len(tokens_a & tokens_b)
    union = len(tokens_a | tokens_b)
    return union > 0 and (intersection / union) >= NEAR_DUPLICATE_THRESHOLD


# ---------------------------------------------------------------------------
# Generalised keyword guarantee
# ---------------------------------------------------------------------------
def _get_must_contain_keywords(query: str) -> list[str]:
    """
    Extract high-signal content keywords from the query that must appear in
    at least one selected chunk.  Uses tokens >5 chars after stopword removal,
    capped at 3 terms.
    """
    tokens = [t for t in _normalize_query_text(query).split() if t and len(t) > 5]
    return sorted(set(tokens), key=lambda t: -len(t))[:3]


def _ensure_keyword_coverage(
    selected: list[RetrievedChunk],
    scored_pool: list[tuple[float, RetrievedChunk]],
    keywords: list[str],
    max_chunks: int,
) -> list[RetrievedChunk]:
    """
    For each required keyword, ensure at least one selected chunk contains it.
    Strategy: swap the weakest non-matching chunk, or append if room available.
    """
    for kw in keywords:
        has_kw = any(kw in _normalize_chunk_text(c["text"]).lower() for c in selected)
        if has_kw:
            continue

        for _, candidate in scored_pool:
            if kw not in _normalize_chunk_text(candidate["text"]).lower():
                continue

            # Prefer swapping a chunk that contains no required keyword at all
            replaced = False
            for i, existing in enumerate(selected):
                existing_norm = _normalize_chunk_text(existing["text"]).lower()
                if not any(k in existing_norm for k in keywords):
                    selected[i] = candidate
                    replaced = True
                    print(f"[RAG] Keyword guarantee: swapped slot {i+1} to include '{kw}'")
                    break

            if not replaced and len(selected) < max_chunks:
                selected.append(candidate)
                print(f"[RAG] Keyword guarantee: appended chunk for '{kw}'")
            break  # one candidate per keyword is enough

    return selected


# ---------------------------------------------------------------------------
# Context formatting
# ---------------------------------------------------------------------------
def _format_context(chunks: list[RetrievedChunk]) -> str:
    """
    Wrap selected chunks in explicit delimiters so the LLM prompt is unambiguous:

        --- CONTEXT START ---
        [Source: filename (Page N)]
        chunk text

        [Source: filename]
        chunk text
        --- CONTEXT END ---
    """
    lines: list[str] = ["--- CONTEXT START ---"]
    for chunk in chunks:
        doc = chunk.get("file") or "Uploaded Doc"
        page = chunk.get("page")
        source_label = f"{doc} (Page {page})" if page is not None else str(doc)
        excerpt = _normalize_chunk_text(chunk["text"])[:1200]
        lines.append(f"\n[Source: {source_label}]\n{excerpt}")
    lines.append("\n--- CONTEXT END ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def retrieve_chunks(
    query: str,
    top_k: int = 5,
    document_id: str | None = None,
) -> RetrievalResult:
    print("[RAG] Retrieval started")
    collection = get_collection()
    print(f"[RAG] Total chunks in DB: {collection.count()}")
    print(f"[RAG] Query: {query}")

    # 1. Build query variations
    query_variations = _build_query_variations(query)
    print(f"[RAG] Query variations: {query_variations}")

    query_terms = _tokenize(_normalize_query_text(query))
    query_terms_ordered = [t for t in _normalize_query_text(query).split() if t]
    must_keywords = _get_must_contain_keywords(query)
    print(f"[RAG] Must-contain keywords: {must_keywords}")

    # 2. Multi-query retrieval — shared embed model from db.get_embedder()
    where_filter = {"doc_id": document_id} if document_id else None
    n_results = max(top_k, 8)
    embed_model = get_embedder()

    all_results: list[dict[str, Any]] = []
    for variation in query_variations:
        embedding = embed_model.encode(variation, show_progress_bar=False).tolist()
        results = collection.query(
            query_embeddings=[embedding],
            n_results=n_results,
            where=where_filter,
            include=["documents", "metadatas", "distances"],
        )
        retrieved_count = sum(
            len(dl) for dl in (results.get("documents") or []) if isinstance(dl, list)
        )
        print(f"[RAG] Variation '{variation}' → {retrieved_count} raw chunks")
        all_results.append(results)

    # 3. Build candidate pool
    candidates: list[tuple[float, RetrievedChunk]] = []

    for results in all_results:
        docs = results.get("documents") or []
        metadatas_raw = results.get("metadatas") or []
        distances_raw = results.get("distances") or []

        for i, doc_list in enumerate(docs):
            if not isinstance(doc_list, list):
                continue

            meta_list = (
                metadatas_raw[i]
                if i < len(metadatas_raw) and isinstance(metadatas_raw[i], list)
                else []
            )
            dist_list = (
                distances_raw[i]
                if i < len(distances_raw) and isinstance(distances_raw[i], list)
                else []
            )

            for j, raw_chunk in enumerate(doc_list):
                raw_text = str(raw_chunk) if raw_chunk else ""
                cleaned = _clean_broken_sentences(raw_text)
                if not cleaned or len(cleaned) <= 40:
                    continue

                cleaned = cleaned.strip().replace("\n", " ")
                sub_chunks = _word_windows(cleaned)

                metadata: dict[str, Any] = (
                    meta_list[j]
                    if j < len(meta_list) and isinstance(meta_list[j], dict)
                    else {}
                )

                dist_val = dist_list[j] if j < len(dist_list) else None
                semantic_score = (
                    1.0 / (1.0 + float(dist_val))
                    if isinstance(dist_val, (int, float))
                    else 0.0
                )

                page_val = metadata.get("page")
                page: int | None = (
                    page_val if isinstance(page_val, int)
                    else int(page_val) if isinstance(page_val, str) and page_val.isdigit()
                    else None
                )

                for sub_chunk in sub_chunks:
                    candidates.append((
                        semantic_score,
                        {
                            "text": sub_chunk,
                            "file": str(metadata.get("file", "unknown.pdf")),
                            "doc_id": str(metadata.get("doc_id", "")),
                            "page": page,
                            "metadata": metadata,
                        },
                    ))

    # 4. Rerank all candidates
    scored: list[tuple[float, RetrievedChunk]] = [
        (_rerank_score(sem, c["text"], query_terms), c)
        for sem, c in candidates
    ]
    scored.sort(key=lambda x: x[0], reverse=True)
    print(f"[RAG] Candidate pool after rerank: {len(scored)} entries")

    # 5. Deduplicate and select top chunks
    selected: list[RetrievedChunk] = []
    seen_texts: set[str] = set()

    for _score, chunk in scored:
        text_key = _normalize_chunk_text(chunk["text"]).lower()
        if not text_key or text_key in seen_texts:
            continue
        if any(_is_near_duplicate(text_key, _normalize_chunk_text(ex["text"]).lower()) for ex in selected):
            continue
        seen_texts.add(text_key)
        selected.append(chunk)
        if len(selected) >= MAX_SELECTED_CHUNKS:
            break

    # 6. Keyword guarantee pass
    if must_keywords:
        selected = _ensure_keyword_coverage(selected, scored, must_keywords, MAX_SELECTED_CHUNKS)

    # 7. Detailed logging of final selection
    print(f"[RAG] Final selected chunks: {len(selected)}")
    for idx, chunk in enumerate(selected, start=1):
        norm_text = _normalize_chunk_text(chunk.get("text", ""))
        preview = norm_text[:150]
        present_terms = [t for t in query_terms_ordered if t in norm_text.lower()]
        chunk_score = next(
            (s for s, c in scored if _normalize_chunk_text(c["text"]).lower() == norm_text.lower()),
            None,
        )
        score_str = f"{chunk_score:.4f}" if chunk_score is not None else "n/a"
        print(f"[RAG] Chunk {idx} | score={score_str} | keywords_present={present_terms}")
        print(f"[RAG] Chunk {idx} preview: {preview}")

    # 8. Format context with delimiters
    context = _format_context(selected)
    return {"chunks": selected, "context": context}
